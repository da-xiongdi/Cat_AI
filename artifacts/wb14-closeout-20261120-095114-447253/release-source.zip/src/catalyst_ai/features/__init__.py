"""Design-time feature construction."""
