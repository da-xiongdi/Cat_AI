"""Public domain contracts."""
