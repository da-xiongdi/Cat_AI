"""Exploratory baseline training."""
