import json

import numpy as np
import pytest
from sklearn.preprocessing import StandardScaler
from test_experiments import prepared
from test_split import rehash_snapshot

from catalyst_ai.datasets.split import build_paper_split
from catalyst_ai.features.enhanced import EnhancedFeatures
from catalyst_ai.features.pipeline import R1Features
from catalyst_ai.modeling.experiments import _score, run_configured


@pytest.fixture
def experiment(sample, tmp_path, monkeypatch):
    import catalyst_ai.modeling.config as config_module
    import catalyst_ai.storage.feature_catalog as catalog_module

    snapshot, qualification, _ = prepared(sample)
    for i, record in enumerate(snapshot["content"]["records"]):
        record["payload"]["source"].update(doi=f"10.1234/paper{i // 2}", title=f"paper {i // 2}")
    rehash_snapshot(snapshot, qualification)
    split = build_paper_split(snapshot, qualification)
    selection = {
        "content": {
            "binding": {"property_version": "v", "mapping_version": "v"},
            "retained": {
                p: split["content"]["splits"][p]["record_ids"]
                for p in ("train", "validation", "test")
            },
        },
        "content_sha256": "selection",
    }
    selection["content"]["excluded"] = {p: [] for p in ("train", "validation", "test")}
    docs = {
        "snapshot": snapshot,
        "qualification": qualification,
        "split": split,
        "selection": selection,
        "features": {"content_sha256": "features"},
    }
    for name, document in docs.items():
        (tmp_path / f"{name}.json").write_text(json.dumps(document), encoding="utf-8")
    from catalyst_ai.features.physchem import PROPERTIES

    properties = {
        "catalog": {
            "entries": [
                {"element": "A", "property": prop, "state": "available", "value": 1.0}
                for prop in PROPERTIES
            ]
        }
    }
    species = {
        "catalog": {
            "entries": [
                {"species": f"X{i}", "state": "supported", "centers": {"A": 1}} for i in range(12)
            ]
        }
    }
    catalogs = (properties, species)
    monkeypatch.setattr(
        catalog_module,
        "get_catalog",
        lambda db, kind, version: properties if kind == "properties" else species,
    )
    effective = {
        "mode": "custom_train",
        "dataset": {**{n: f"{n}.json" for n in docs}, "catalog_database": "catalog"},
        "features": {"preset": "R2", "sets": ["F2", "F1", "F_base"]},
        "models": [{"name": "ridge", "params": {"alpha": 2.0}}, {"name": "dummy", "params": {}}],
        "validation": {"n_splits": 2},
        "seed": 17,
        "output": "run",
    }
    monkeypatch.setattr(config_module, "load_config", lambda _: {"effective_config": effective})
    return tmp_path, docs, effective, catalogs


def test_custom_folds_vocab_scaling_and_oof(experiment, monkeypatch):
    path, docs, config, catalogs = experiment
    fitted_scalers = []
    original_fit = StandardScaler.fit

    def capture(self, X, y=None, **kwargs):
        result = original_fit(self, X, y, **kwargs)
        fitted_scalers.append((self.mean_.copy(), self.n_samples_seen_))
        return result

    monkeypatch.setattr(StandardScaler, "fit", capture)
    report, fitted = run_configured(path / "config.yaml")
    records = {r["record_id"]: r for r in docs["snapshot"]["content"]["records"]}
    assert set(fitted) == {(f, m) for f in config["features"]["sets"] for m in ("ridge", "dummy")}
    assert fitted["F_base", "ridge"][1].named_steps["ridge"].alpha == 2
    seen = []
    for fold in report["fold_details"]:
        train = [records[i]["payload"] for i in fold["training_record_ids"]]
        hold = [records[i]["payload"] for i in fold["held_out_record_ids"]]
        assert not {p["source"]["doi"] for p in train} & {p["source"]["doi"] for p in hold}
        seen.extend(fold["held_out_record_ids"])
        for feature in config["features"]["sets"]:
            transform = (
                R1Features.fit(train, feature)
                if feature == "F_base"
                else EnhancedFeatures.fit(
                    train, feature, properties=catalogs[0], species=catalogs[1]
                )
            )
            vocab = transform.vocabulary if feature == "F_base" else transform.base.vocabulary
            assert fold["features"][feature]["vocabulary"] == [list(k) for k in vocab]
            assert not {("compound", "X" + str(int(i))) for i in fold["held_out_record_ids"]} & set(
                vocab
            )
            matrix = np.asarray([transform.transform_one(p)["values"] for p in train])
            mean, count = fitted_scalers.pop(0)
            np.testing.assert_allclose(mean, matrix.mean(axis=0))
            assert count == len(train)
    train_ids = docs["selection"]["content"]["retained"]["train"]
    assert sorted(seen) == sorted(train_ids)
    for feature in config["features"]["sets"]:
        for model in ("dummy", "ridge"):
            rows = report["oof_predictions"][feature][model]
            assert sorted(r["record_id"] for r in rows) == sorted(train_ids)
            assert report["oof_scores"][feature][model] == _score(rows)


def test_custom_ties_single_model_and_holdout_isolation(experiment):
    path, docs, config, _ = experiment
    for record in docs["snapshot"]["content"]["records"]:
        record["payload"]["observations"][0]["value"]["normalized_value"] = 15
    snapshot_path = path / "snapshot.json"
    snapshot_path.write_text(json.dumps(docs["snapshot"]), encoding="utf-8")
    report, _ = run_configured(path / "config.yaml")
    assert report["selected"] == {"feature_set": "F_base", "model": "dummy"}
    config["output"] = "single"
    config["models"] = [config["models"][0]]
    single, fitted = run_configured(path / "config.yaml")
    assert single["selected"] == {"feature_set": "F_base", "model": "ridge"}
    assert len(fitted) == 3
    for part in ("validation", "test"):
        for record in docs["snapshot"]["content"]["records"]:
            if record["record_id"] in docs["selection"]["content"]["retained"][part]:
                record["payload"]["observations"][0]["value"]["normalized_value"] += 30
    snapshot_path.write_text(json.dumps(docs["snapshot"]), encoding="utf-8")
    config["output"] = "changed"
    changed, _ = run_configured(path / "config.yaml")
    assert changed["selected"] == single["selected"]
    assert changed["oof_predictions"] == single["oof_predictions"]
    assert changed["oof_scores"] == single["oof_scores"]
    assert changed["validation"] != single["validation"]
    assert changed["test"] != single["test"]


def test_oof_paper_weight_is_not_fold_or_record_weight():
    rows = [
        {"doi": "a", "observed": 0, "raw_prediction": 1},
        {"doi": "a", "observed": 0, "raw_prediction": 1},
        {"doi": "b", "observed": 0, "raw_prediction": 7},
    ]
    assert _score(rows)["paper_equal_mae"] == 4
    assert _score(rows)["mae"] == 3
